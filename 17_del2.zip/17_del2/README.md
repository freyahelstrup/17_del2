# 17_del2
Gruppe 17's CDIO projekt, efterår 2016, del 2
